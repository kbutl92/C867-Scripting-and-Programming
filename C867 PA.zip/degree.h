#pragma once
	enum Degree {
		notSpecified = 0,
		SECURITY,
		NETWORKING,
		SOFTWARE
	};